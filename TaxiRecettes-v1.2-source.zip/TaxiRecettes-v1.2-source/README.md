# Taxi Recettes v1.2 — reconstruction

Cette version est reconstruite à partir de l'APK v1.1 et des deux formulaires Autolux fournis.

## Changement principal
- Photo de la feuille « Détail de la recette ».
- Rotation automatique par reconnaissance des en-têtes.
- Découpage des 12 lignes et des colonnes connues du formulaire.
- OCR ML Kit sur chaque case, avec un second passage en contraste renforcé.
- Normalisation des chiffres manuscrits (notamment O/o → 0), virgule/point et signes +/−.
- Écran obligatoire de vérification/correction.
- Saisie manuelle toujours disponible.
- Photo de l'enveloppe et tentative de lecture des montants associés aux libellés principaux.
- Calculs automatiques après correction.

## Important
La reconnaissance de chiffres manuscrits à partir d'une photo n'est jamais fiable à 100 %. L'application privilégie donc un flux « lecture → contrôle → correction → calcul » et n'empêche jamais la saisie manuelle.

## Build
Ouvrir le projet dans Android Studio récent, synchroniser Gradle, puis Build > Build APK(s).

Le package reste `be.taxirecettes.app`. Si l'ancienne APK a été signée avec une autre clé, Android demandera de désinstaller l'ancienne version avant d'installer celle-ci.
