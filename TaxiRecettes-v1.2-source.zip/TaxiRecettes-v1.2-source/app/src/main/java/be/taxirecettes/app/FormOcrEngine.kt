package be.taxirecettes.app

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max

class FormOcrEngine {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun analyzeDetail(input: Bitmap): List<DetailRow> {
        val canonical = bestDetailOrientation(input)
        val rows = MutableList(12) { DetailRow() }
        val yTop = 0.184f
        val yBottom = 0.884f
        val rowH = (yBottom - yTop) / 12f
        // x fractions measured from the user's Autolux detail sheet.
        val cols = listOf(0.075f to 0.248f, 0.250f to 0.385f, 0.386f to 0.520f, 0.520f to 0.655f, 0.655f to 0.900f)
        for (i in 0 until 12) {
            val top = yTop + i * rowH + rowH * 0.06f
            val bottom = yTop + (i + 1) * rowH - rowH * 0.06f
            val values = mutableListOf<String>()
            for ((ci, col) in cols.withIndex()) {
                val crop = BitmapUtils.cropFraction(canonical, col.first, top, col.second, bottom)
                val text = if (ci < 4) recognizeMoneyCell(crop) else recognize(crop).text.trim()
                values += text
            }
            rows[i].taximeter = parseMoney(values[0])
            rows[i].adjustment = parseSignedMoney(values[1])
            rows[i].salaryBase = parseMoney(values[2])
            rows[i].toReturn = parseMoney(values[3])
            rows[i].observation = values[4]
            val recognized = values.take(4).count { parseMoney(it) != null || parseSignedMoney(it) != null }
            rows[i].confidence = recognized / 4f
        }
        return rows
    }

    suspend fun analyzeEnvelope(input: Bitmap): EnvelopeData {
        val candidates = listOf(input, BitmapUtils.rotate(input,90f), BitmapUtils.rotate(input,180f), BitmapUtils.rotate(input,270f))
        var best: Text? = null
        var score = -1
        for (b in candidates) {
            val t = recognize(b)
            val s = listOf("total non", "ticket machine", "recette", "argent").count { t.text.lowercase().contains(it) }
            if (s > score) { score = s; best = t }
        }
        val full = best?.text.orEmpty()
        // Conservative: only fill values that are clearly attached to known labels. User can correct manually.
        return EnvelopeData(
            nonCash = valueAfterLabel(full, listOf("total non paye en argent", "total non payé en argent")),
            ticketMachine = valueAfterLabel(full, listOf("total argent ticket")),
            cash = valueAfterLabel(full, listOf("total 1+2")),
            reimbursements = valueAfterLabel(full, listOf("frais a rembourser", "frais à rembourser"))
        )
    }

    private suspend fun bestDetailOrientation(src: Bitmap): Bitmap {
        val variants = listOf(src, BitmapUtils.rotate(src,90f), BitmapUtils.rotate(src,180f), BitmapUtils.rotate(src,270f))
        var best = variants.first(); var bestScore = -1
        for (b in variants) {
            val text = recognize(Bitmap.createScaledBitmap(b, max(1,b.width/3), max(1,b.height/3), true)).text.lowercase()
            val score = listOf("montant", "taxim", "deduire", "déduire", "base", "salaire", "recette", "observations").count { text.contains(it) }
            if (score > bestScore) { bestScore = score; best = b }
        }
        // The detail form is landscape in its canonical orientation.
        return if (best.width >= best.height) best else BitmapUtils.rotate(best,90f)
    }

    private suspend fun recognizeMoneyCell(cell: Bitmap): String {
        val a = recognize(cell).text.trim()
        val b = recognize(BitmapUtils.highContrast(cell)).text.trim()
        val ca = moneyCandidate(a)
        val cb = moneyCandidate(b)
        return when {
            ca != null && cb != null -> if (ca.length >= cb.length) ca else cb
            ca != null -> ca
            cb != null -> cb
            else -> a.ifBlank { b }
        }
    }

    private fun moneyCandidate(s: String): String? {
        val cleaned = s.replace("€","").replace(" ","").replace('O','0').replace('o','0')
        return Regex("[-+]?\\d{1,4}([,.]\\d{1,2})?").find(cleaned)?.value
    }

    fun parseMoney(s: String): Double? = moneyCandidate(s)?.replace(',','.')?.removePrefix("+")?.toDoubleOrNull()?.let { kotlin.math.abs(it) }
    fun parseSignedMoney(s: String): Double? = moneyCandidate(s)?.replace(',','.')?.toDoubleOrNull()

    private fun valueAfterLabel(text: String, labels: List<String>): Double? {
        val normalized = text.lowercase().replace('\n',' ')
        for (label in labels) {
            val idx = normalized.indexOf(label)
            if (idx >= 0) {
                val tail = normalized.substring(idx + label.length).take(80)
                moneyCandidate(tail)?.replace(',','.')?.toDoubleOrNull()?.let { return it }
            }
        }
        return null
    }

    private suspend fun recognize(bitmap: Bitmap): Text = suspendCancellableCoroutine { cont ->
        recognizer.process(InputImage.fromBitmap(bitmap,0))
            .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
            .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
    }
}
