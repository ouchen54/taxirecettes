package be.taxirecettes.app

import android.content.ContentResolver
import android.graphics.*
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

object BitmapUtils {
    fun load(resolver: ContentResolver, uri: Uri, maxSide: Int = 2400): Bitmap {
        val bytes = resolver.openInputStream(uri)!!.use { it.readBytes() }
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        var sample = 1
        while (max(opts.outWidth, opts.outHeight) / sample > maxSide) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
        val orientation = try { ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
        val deg = when (orientation) { ExifInterface.ORIENTATION_ROTATE_90 -> 90f; ExifInterface.ORIENTATION_ROTATE_180 -> 180f; ExifInterface.ORIENTATION_ROTATE_270 -> 270f; else -> 0f }
        return if (deg == 0f) bmp else rotate(bmp, deg)
    }

    fun rotate(src: Bitmap, deg: Float): Bitmap {
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    fun cropFraction(src: Bitmap, l: Float, t: Float, r: Float, b: Float, pad: Float = 0.005f): Bitmap {
        val x1 = ((l - pad).coerceAtLeast(0f) * src.width).toInt()
        val y1 = ((t - pad).coerceAtLeast(0f) * src.height).toInt()
        val x2 = ((r + pad).coerceAtMost(1f) * src.width).toInt()
        val y2 = ((b + pad).coerceAtMost(1f) * src.height).toInt()
        return Bitmap.createBitmap(src, x1, y1, max(1, x2-x1), max(1, y2-y1))
    }

    fun highContrast(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val cm = ColorMatrix(floatArrayOf(
            1.8f,0f,0f,0f,-100f,
            0f,1.8f,0f,0f,-100f,
            0f,0f,1.8f,0f,-100f,
            0f,0f,0f,1f,0f
        ))
        cm.setSaturation(0f)
        p.colorFilter = ColorMatrixColorFilter(cm)
        c.drawBitmap(src,0f,0f,p)
        return out
    }
}
