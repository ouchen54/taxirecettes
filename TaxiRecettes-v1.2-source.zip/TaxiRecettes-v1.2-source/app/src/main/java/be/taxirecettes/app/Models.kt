package be.taxirecettes.app

data class DetailRow(
    var taximeter: Double? = null,
    var adjustment: Double? = null,
    var salaryBase: Double? = null,
    var toReturn: Double? = null,
    var observation: String = "",
    var confidence: Float = 0f
)

data class EnvelopeData(
    var nonCash: Double? = null,
    var cash: Double? = null,
    var ticketMachine: Double? = null,
    var reimbursements: Double? = null
)

data class Totals(
    val taximeter: Double,
    val salaryBase: Double,
    val recipePatron: Double,
    val nonCash: Double,
    val cashToReturn: Double
)
