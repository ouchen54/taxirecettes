package be.taxirecettes.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.launch
import java.io.File
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val ocr = FormOcrEngine()
    private var mode = "detail"
    private var pendingUri: Uri? = null
    private var detailRows = MutableList(12) { DetailRow() }
    private var envelope = EnvelopeData()
    private lateinit var root: LinearLayout
    private val nf = NumberFormat.getNumberInstance(Locale.FRANCE).apply { minimumFractionDigits=2; maximumFractionDigits=2 }

    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok -> if (ok) pendingUri?.let { analyze(it) } }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let(::analyze) }
    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) launchCamera() }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showHome() }

    private fun shell(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(14),dp(14),dp(14)) }
        val scroll = ScrollView(this)
        val body = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(body)
        root.addView(TextView(this).apply { text=title; textSize=25f; setTypeface(typeface,Typeface.BOLD); setPadding(0,0,0,dp(10)) })
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        return body
    }

    private fun showHome() {
        val b=shell("Taxi Recettes 1.2")
        b.addView(TextView(this).apply { text="Photo → lecture des chiffres → correction → calcul automatique. Rien n'est validé sans pouvoir être corrigé."; textSize=16f; setPadding(0,0,0,dp(14)) })
        b.addView(button("📷 Scanner la feuille DÉTAIL DE RECETTE") { mode="detail"; chooseSource() })
        b.addView(button("📷 Scanner l'ENVELOPPE") { mode="envelope"; chooseSource() })
        b.addView(button("✍️ Saisie / correction manuelle") { showEditor() })
        b.addView(button("🧮 Voir les calculs") { showTotals() })
    }

    private fun chooseSource() {
        android.app.AlertDialog.Builder(this).setTitle("Ajouter la photo")
            .setItems(arrayOf("Prendre une photo","Choisir dans la galerie")) { _,i -> if(i==0) ensureCamera() else pickImage.launch("image/*") }.show()
    }

    private fun ensureCamera() {
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) launchCamera()
        else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun launchCamera() {
        val dir=File(filesDir,"photos").apply{mkdirs()}
        val f=File(dir,"${mode}_${System.currentTimeMillis()}.jpg")
        pendingUri=FileProvider.getUriForFile(this,"$packageName.files",f)
        takePicture.launch(pendingUri)
    }

    private fun analyze(uri: Uri) {
        val b=shell("Analyse de la photo…")
        val p=ProgressBar(this); b.addView(p)
        b.addView(TextView(this).apply{text="Lecture case par case. Les montants incertains pourront être corrigés.";setPadding(0,dp(12),0,0)})
        lifecycleScope.launch {
            try {
                val bmp=BitmapUtils.load(contentResolver,uri)
                if(mode=="detail") detailRows=ocr.analyzeDetail(bmp).toMutableList() else envelope=ocr.analyzeEnvelope(bmp)
                showEditor()
            } catch(e:Exception) {
                Toast.makeText(this@MainActivity,"Lecture impossible : ${e.message}",Toast.LENGTH_LONG).show(); showEditor()
            }
        }
    }

    private fun showEditor() {
        val b=shell("Vérifier / corriger")
        b.addView(TextView(this).apply{text="Touchez n'importe quel montant pour le modifier. Les lignes jaunes/vides sont à vérifier."; setPadding(0,0,0,dp(10))})
        detailRows.forEachIndexed { idx,row -> b.addView(rowCard(idx,row)) }
        b.addView(TextView(this).apply{text="Enveloppe";textSize=20f;setTypeface(typeface,Typeface.BOLD);setPadding(0,dp(14),0,dp(5))})
        val nonCash=moneyEdit("Total non-cash encaissé", envelope.nonCash) { envelope.nonCash=it }; b.addView(nonCash)
        val cash=moneyEdit("Total cash / Total 1+2 (facultatif)", envelope.cash) { envelope.cash=it }; b.addView(cash)
        val ticket=moneyEdit("Ticket machine à billets", envelope.ticketMachine) { envelope.ticketMachine=it }; b.addView(ticket)
        b.addView(button("+ Ajouter une ligne") { detailRows.add(DetailRow()); showEditor() })
        b.addView(button("Calculer les totaux") { showTotals() })
        b.addView(button("Accueil") { showHome() })
    }

    private fun rowCard(index:Int,row:DetailRow): View {
        val card=MaterialCardView(this).apply { setContentPadding(dp(10),dp(8),dp(10),dp(8)); radius=dp(10).toFloat(); strokeWidth=if(row.confidence<0.5f) dp(2) else dp(1); setPadding(0,dp(4),0,dp(4)) }
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(TextView(this).apply{text="Course ${index+1}";setTypeface(typeface,Typeface.BOLD)})
        box.addView(moneyEdit("Montant taximètre",row.taximeter){row.taximeter=it; autoRow(row)})
        box.addView(moneyEdit("À déduire / ajouter (+ ou -)",row.adjustment, signed=true){row.adjustment=it; autoRow(row)})
        box.addView(moneyEdit("Base salaire",row.salaryBase){row.salaryBase=it})
        box.addView(moneyEdit("Recette à rentrer",row.toReturn){row.toReturn=it})
        val obs=EditText(this).apply{hint="Observations";setText(row.observation);setSingleLine();setOnFocusChangeListener{_,has->if(!has)row.observation=text.toString()}}
        box.addView(obs)
        card.addView(box); return card
    }

    private fun autoRow(r:DetailRow) { val v=(r.taximeter?:0.0)+(r.adjustment?:0.0); r.salaryBase=v; r.toReturn=v }

    private fun moneyEdit(label:String,value:Double?,signed:Boolean=false,onChange:(Double?)->Unit): View {
        val wrap=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,dp(3),0,dp(3))}
        wrap.addView(TextView(this).apply{text=label;textSize=13f})
        val e=EditText(this).apply{
            inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or if(signed) InputType.TYPE_NUMBER_FLAG_SIGNED else 0
            hint="0,00"; setText(value?.let{nf.format(it)} ?: "")
            setOnFocusChangeListener{_,has-> if(!has) onChange(text.toString().replace(" ","").replace(',','.').toDoubleOrNull()) }
        }
        wrap.addView(e); return wrap
    }

    private fun showTotals() {
        val t=Rules.recompute(detailRows,envelope)
        val b=shell("Résultat de la journée")
        fun line(name:String,v:Double)=TextView(this).apply{text="$name : ${nf.format(v)} €";textSize=19f;setPadding(0,dp(7),0,dp(7))}
        b.addView(line("Total taximètre",t.taximeter)); b.addView(line("Base salaire",t.salaryBase)); b.addView(line("Recette patron",t.recipePatron)); b.addView(line("Non-cash",t.nonCash)); b.addView(line("Argent à remettre",t.cashToReturn))
        b.addView(button("Corriger") { showEditor() }); b.addView(button("Accueil") { showHome() })
    }

    private fun button(text:String,click:()->Unit)=MaterialButton(this).apply{this.text=text;setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
