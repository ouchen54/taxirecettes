package be.taxirecettes.app

object Rules {
    fun recompute(rows: List<DetailRow>, envelope: EnvelopeData): Totals {
        rows.forEach { row ->
            val t = row.taximeter ?: 0.0
            val adj = row.adjustment ?: 0.0
            if (row.salaryBase == null) row.salaryBase = t + adj
            if (row.toReturn == null) row.toReturn = t + adj
        }
        val totalTaximeter = rows.sumOf { it.taximeter ?: 0.0 }
        val totalSalary = rows.sumOf { it.salaryBase ?: 0.0 }
        val patron = rows.sumOf { it.toReturn ?: 0.0 }
        val nonCash = envelope.nonCash ?: 0.0
        val cash = patron - nonCash
        return Totals(totalTaximeter, totalSalary, patron, nonCash, cash)
    }
}
